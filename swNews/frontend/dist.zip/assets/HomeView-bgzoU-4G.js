import{u as Mt,t as De,c as Lt,a as et,p as Ut,b as Bt,i as Wt,d as Zt,e as te,f as ge,r as L,o as Ft,h as S,g as Xt,j as g,k as tt,l as nt,m as Yt,n as f,q as V,s as v,v as Ht,w as Kt,x as qt,y as Gt,z as fe,A as ot,B as Jt,C as Qt,V as Ue,D as Be,E as en,F as tn,T as nn,G as Q,H as We,I as Ze,J as on,K as sn,L as ee,M as an,N as m,O as b,_ as ve,P as c,Q as rn,R as ln,S as un,U as cn,W as dn}from"./index-nwpq3E5K.js";import{_ as fn,a as vn}from"./Grid-BytYFXqO.js";import{_ as pn}from"./Flex-DxgHfKA6.js";import"./get-slot-Bk_rJcZu.js";function hn(e){return Mt(De(e).toLowerCase())}function gn(e,o,s,l){var r=-1,h=e==null?0:e.length;for(l&&h&&(s=e[++r]);++r<h;)s=o(s,e[r],r,e);return s}function xn(e){return function(o){return e==null?void 0:e[o]}}var mn={À:"A",Á:"A",Â:"A",Ã:"A",Ä:"A",Å:"A",à:"a",á:"a",â:"a",ã:"a",ä:"a",å:"a",Ç:"C",ç:"c",Ð:"D",ð:"d",È:"E",É:"E",Ê:"E",Ë:"E",è:"e",é:"e",ê:"e",ë:"e",Ì:"I",Í:"I",Î:"I",Ï:"I",ì:"i",í:"i",î:"i",ï:"i",Ñ:"N",ñ:"n",Ò:"O",Ó:"O",Ô:"O",Õ:"O",Ö:"O",Ø:"O",ò:"o",ó:"o",ô:"o",õ:"o",ö:"o",ø:"o",Ù:"U",Ú:"U",Û:"U",Ü:"U",ù:"u",ú:"u",û:"u",ü:"u",Ý:"Y",ý:"y",ÿ:"y",Æ:"Ae",æ:"ae",Þ:"Th",þ:"th",ß:"ss",Ā:"A",Ă:"A",Ą:"A",ā:"a",ă:"a",ą:"a",Ć:"C",Ĉ:"C",Ċ:"C",Č:"C",ć:"c",ĉ:"c",ċ:"c",č:"c",Ď:"D",Đ:"D",ď:"d",đ:"d",Ē:"E",Ĕ:"E",Ė:"E",Ę:"E",Ě:"E",ē:"e",ĕ:"e",ė:"e",ę:"e",ě:"e",Ĝ:"G",Ğ:"G",Ġ:"G",Ģ:"G",ĝ:"g",ğ:"g",ġ:"g",ģ:"g",Ĥ:"H",Ħ:"H",ĥ:"h",ħ:"h",Ĩ:"I",Ī:"I",Ĭ:"I",Į:"I",İ:"I",ĩ:"i",ī:"i",ĭ:"i",į:"i",ı:"i",Ĵ:"J",ĵ:"j",Ķ:"K",ķ:"k",ĸ:"k",Ĺ:"L",Ļ:"L",Ľ:"L",Ŀ:"L",Ł:"L",ĺ:"l",ļ:"l",ľ:"l",ŀ:"l",ł:"l",Ń:"N",Ņ:"N",Ň:"N",Ŋ:"N",ń:"n",ņ:"n",ň:"n",ŋ:"n",Ō:"O",Ŏ:"O",Ő:"O",ō:"o",ŏ:"o",ő:"o",Ŕ:"R",Ŗ:"R",Ř:"R",ŕ:"r",ŗ:"r",ř:"r",Ś:"S",Ŝ:"S",Ş:"S",Š:"S",ś:"s",ŝ:"s",ş:"s",š:"s",Ţ:"T",Ť:"T",Ŧ:"T",ţ:"t",ť:"t",ŧ:"t",Ũ:"U",Ū:"U",Ŭ:"U",Ů:"U",Ű:"U",Ų:"U",ũ:"u",ū:"u",ŭ:"u",ů:"u",ű:"u",ų:"u",Ŵ:"W",ŵ:"w",Ŷ:"Y",ŷ:"y",Ÿ:"Y",Ź:"Z",Ż:"Z",Ž:"Z",ź:"z",ż:"z",ž:"z",Ĳ:"IJ",ĳ:"ij",Œ:"Oe",œ:"oe",ŉ:"'n",ſ:"s"},bn=xn(mn);const _n=bn;var wn=/[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g,yn="\\u0300-\\u036f",Sn="\\ufe20-\\ufe2f",Cn="\\u20d0-\\u20ff",Rn=yn+Sn+Cn,zn="["+Rn+"]",Pn=RegExp(zn,"g");function kn(e){return e=De(e),e&&e.replace(wn,_n).replace(Pn,"")}var In=/[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g;function Dn(e){return e.match(In)||[]}var An=/[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/;function En(e){return An.test(e)}var st="\\ud800-\\udfff",Nn="\\u0300-\\u036f",$n="\\ufe20-\\ufe2f",Tn="\\u20d0-\\u20ff",Vn=Nn+$n+Tn,at="\\u2700-\\u27bf",rt="a-z\\xdf-\\xf6\\xf8-\\xff",jn="\\xac\\xb1\\xd7\\xf7",On="\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf",Mn="\\u2000-\\u206f",Ln=" \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000",it="A-Z\\xc0-\\xd6\\xd8-\\xde",Un="\\ufe0e\\ufe0f",lt=jn+On+Mn+Ln,ut="['’]",Fe="["+lt+"]",Bn="["+Vn+"]",ct="\\d+",Wn="["+at+"]",dt="["+rt+"]",ft="[^"+st+lt+ct+at+rt+it+"]",Zn="\\ud83c[\\udffb-\\udfff]",Fn="(?:"+Bn+"|"+Zn+")",Xn="[^"+st+"]",vt="(?:\\ud83c[\\udde6-\\uddff]){2}",pt="[\\ud800-\\udbff][\\udc00-\\udfff]",H="["+it+"]",Yn="\\u200d",Xe="(?:"+dt+"|"+ft+")",Hn="(?:"+H+"|"+ft+")",Ye="(?:"+ut+"(?:d|ll|m|re|s|t|ve))?",He="(?:"+ut+"(?:D|LL|M|RE|S|T|VE))?",ht=Fn+"?",gt="["+Un+"]?",Kn="(?:"+Yn+"(?:"+[Xn,vt,pt].join("|")+")"+gt+ht+")*",qn="\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])",Gn="\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])",Jn=gt+ht+Kn,Qn="(?:"+[Wn,vt,pt].join("|")+")"+Jn,eo=RegExp([H+"?"+dt+"+"+Ye+"(?="+[Fe,H,"$"].join("|")+")",Hn+"+"+He+"(?="+[Fe,H+Xe,"$"].join("|")+")",H+"?"+Xe+"+"+Ye,H+"+"+He,Gn,qn,ct,Qn].join("|"),"g");function to(e){return e.match(eo)||[]}function no(e,o,s){return e=De(e),o=s?void 0:o,o===void 0?En(e)?to(e):Dn(e):e.match(o)||[]}var oo="['’]",so=RegExp(oo,"g");function ao(e){return function(o){return gn(no(kn(o).replace(so,"")),e,"")}}var Ke=ao(function(e,o,s){return o=o.toLowerCase(),e+(s?hn(o):o)});const ro=e=>({dotSize:"8px",dotColor:"rgba(255, 255, 255, .3)",dotColorActive:"rgba(255, 255, 255, 1)",dotColorFocus:"rgba(255, 255, 255, .5)",dotLineWidth:"16px",dotLineWidthActive:"24px",arrowColor:"#eee"}),io={name:"Carousel",common:Lt,self:ro},lo=io;function uo(e){const{length:o}=e;return o>1&&(e.push(qe(e[0],0,"append")),e.unshift(qe(e[o-1],o-1,"prepend"))),e}function qe(e,o,s){return et(e,{key:`carousel-item-duplicate-${o}-${s}`})}function Ge(e,o,s){return o===1?0:s?e===0?o-3:e===o-1?0:e-1:e}function ke(e,o){return o?e+1:e}function co(e,o,s){return e<0?null:e===0?s?o-1:null:e-1}function fo(e,o,s){return e>o-1?null:e===o-1?s?0:null:e+1}function vo(e,o){return o&&e>3?e-2:e}function Je(e){return window.TouchEvent&&e instanceof window.TouchEvent}function Qe(e,o){let{offsetWidth:s,offsetHeight:l}=e;if(o){const r=getComputedStyle(e);s=s-parseFloat(r.getPropertyValue("padding-left"))-parseFloat(r.getPropertyValue("padding-right")),l=l-parseFloat(r.getPropertyValue("padding-top"))-parseFloat(r.getPropertyValue("padding-bottom"))}return{width:s,height:l}}function pe(e,o,s){return e<o?o:e>s?s:e}function po(e){if(e===void 0)return 0;if(typeof e=="number")return e;const o=/^((\d+)?\.?\d+?)(ms|s)?$/,s=e.match(o);if(s){const[,l,,r="ms"]=s;return Number(l)*(r==="ms"?1:1e3)}return 0}const xt=Bt("n-carousel-methods"),ho=e=>{Ut(xt,e)},Ae=(e="unknown",o="component")=>{const s=Wt(xt);return s||Zt(e,`\`${o}\` must be placed inside \`n-carousel\`.`),s},go={total:{type:Number,default:0},currentIndex:{type:Number,default:0},dotType:{type:String,default:"dot"},trigger:{type:String,default:"click"},keyboard:Boolean},xo=te({name:"CarouselDots",props:go,setup(e){const{mergedClsPrefixRef:o}=ge(e),s=L([]),l=Ae();function r(_,p){switch(_.key){case"Enter":case" ":_.preventDefault(),l.to(p);return}e.keyboard&&z(_)}function h(_){e.trigger==="hover"&&l.to(_)}function R(_){e.trigger==="click"&&l.to(_)}function z(_){var p;if(_.shiftKey||_.altKey||_.ctrlKey||_.metaKey)return;const y=(p=document.activeElement)===null||p===void 0?void 0:p.nodeName.toLowerCase();if(y==="input"||y==="textarea")return;const{code:I}=_,U=I==="PageUp"||I==="ArrowUp",B=I==="PageDown"||I==="ArrowDown",k=I==="PageUp"||I==="ArrowRight",D=I==="PageDown"||I==="ArrowLeft",A=l.isVertical(),O=A?U:k,K=A?B:D;!O&&!K||(_.preventDefault(),O&&!l.isNextDisabled()?(l.next(),P(l.currentIndexRef.value)):K&&!l.isPrevDisabled()&&(l.prev(),P(l.currentIndexRef.value)))}function P(_){var p;(p=s.value[_])===null||p===void 0||p.focus()}return Ft(()=>s.value.length=0),{mergedClsPrefix:o,dotEls:s,handleKeydown:r,handleMouseenter:h,handleClick:R}},render(){const{mergedClsPrefix:e,dotEls:o}=this;return S("div",{class:[`${e}-carousel__dots`,`${e}-carousel__dots--${this.dotType}`],role:"tablist"},Xt(this.total,s=>{const l=s===this.currentIndex;return S("div",{"aria-selected":l,ref:r=>o.push(r),role:"button",tabindex:"0",class:[`${e}-carousel__dot`,l&&`${e}-carousel__dot--active`],key:s,onClick:()=>{this.handleClick(s)},onMouseenter:()=>{this.handleMouseenter(s)},onKeydown:r=>{this.handleKeydown(r,s)}})}))}}),mo=S("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 16 16"},S("g",{fill:"none"},S("path",{d:"M10.26 3.2a.75.75 0 0 1 .04 1.06L6.773 8l3.527 3.74a.75.75 0 1 1-1.1 1.02l-4-4.25a.75.75 0 0 1 0-1.02l4-4.25a.75.75 0 0 1 1.06-.04z",fill:"currentColor"}))),bo=S("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 16 16"},S("g",{fill:"none"},S("path",{d:"M5.74 3.2a.75.75 0 0 0-.04 1.06L9.227 8L5.7 11.74a.75.75 0 1 0 1.1 1.02l4-4.25a.75.75 0 0 0 0-1.02l-4-4.25a.75.75 0 0 0-1.06-.04z",fill:"currentColor"}))),_o=te({name:"CarouselArrow",setup(e){const{mergedClsPrefixRef:o}=ge(e),{isVertical:s,isPrevDisabled:l,isNextDisabled:r,prev:h,next:R}=Ae();return{mergedClsPrefix:o,isVertical:s,isPrevDisabled:l,isNextDisabled:r,prev:h,next:R}},render(){const{mergedClsPrefix:e}=this;return S("div",{class:`${e}-carousel__arrow-group`},S("div",{class:[`${e}-carousel__arrow`,this.isPrevDisabled()&&`${e}-carousel__arrow--disabled`],role:"button",onClick:this.prev},mo),S("div",{class:[`${e}-carousel__arrow`,this.isNextDisabled()&&`${e}-carousel__arrow--disabled`],role:"button",onClick:this.next},bo))}}),he="CarouselItem",wo=e=>{var o;return((o=e.type)===null||o===void 0?void 0:o.name)===he},yo=te({name:he,setup(e){const{mergedClsPrefixRef:o}=ge(e),s=Ae(Ke(he),`n-${Ke(he)}`),l=L(),r=g(()=>{const{value:p}=l;return p?s.getSlideIndex(p):-1}),h=g(()=>s.isPrev(r.value)),R=g(()=>s.isNext(r.value)),z=g(()=>s.isActive(r.value)),P=g(()=>s.getSlideStyle(r.value));tt(()=>{s.addSlide(l.value)}),nt(()=>{s.removeSlide(l.value)});function _(p){const{value:y}=r;y!==void 0&&(s==null||s.onCarouselItemClick(y,p))}return{mergedClsPrefix:o,selfElRef:l,isPrev:h,isNext:R,isActive:z,index:r,style:P,handleClick:_}},render(){var e;const{$slots:o,mergedClsPrefix:s,isPrev:l,isNext:r,isActive:h,index:R,style:z}=this,P=[`${s}-carousel__slide`,{[`${s}-carousel__slide--current`]:h,[`${s}-carousel__slide--prev`]:l,[`${s}-carousel__slide--next`]:r}];return S("div",{ref:"selfElRef",class:P,role:"option",tabindex:"-1","data-index":R,"aria-hidden":!h,style:z,onClickCapture:this.handleClick},(e=o.default)===null||e===void 0?void 0:e.call(o,{isPrev:l,isNext:r,isActive:h,index:R}))}}),So=Yt("carousel",`
 position: relative;
 width: 100%;
 height: 100%;
 touch-action: pan-y;
 overflow: hidden;
`,[f("slides",`
 display: flex;
 width: 100%;
 height: 100%;
 transition-timing-function: var(--n-bezier);
 transition-property: transform;
 `,[f("slide",`
 flex-shrink: 0;
 position: relative;
 width: 100%;
 height: 100%;
 outline: none;
 overflow: hidden;
 `,[V("> img",`
 display: block;
 `)])]),f("dots",`
 position: absolute;
 display: flex;
 flex-wrap: nowrap;
 `,[v("dot",[f("dot",`
 height: var(--n-dot-size);
 width: var(--n-dot-size);
 background-color: var(--n-dot-color);
 border-radius: 50%;
 cursor: pointer;
 transition:
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[V("&:focus",`
 background-color: var(--n-dot-color-focus);
 `),v("active",`
 background-color: var(--n-dot-color-active);
 `)])]),v("line",[f("dot",`
 border-radius: 9999px;
 width: var(--n-dot-line-width);
 height: 4px;
 background-color: var(--n-dot-color);
 cursor: pointer;
 transition:
 width .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[V("&:focus",`
 background-color: var(--n-dot-color-focus);
 `),v("active",`
 width: var(--n-dot-line-width-active);
 background-color: var(--n-dot-color-active);
 `)])])]),f("arrow",`
 transition: background-color .3s var(--n-bezier);
 cursor: pointer;
 height: 28px;
 width: 28px;
 display: flex;
 align-items: center;
 justify-content: center;
 background-color: rgba(255, 255, 255, .2);
 color: var(--n-arrow-color);
 border-radius: 8px;
 user-select: none;
 -webkit-user-select: none;
 font-size: 18px;
 `,[V("svg",`
 height: 1em;
 width: 1em;
 `),V("&:hover",`
 background-color: rgba(255, 255, 255, .3);
 `)]),v("vertical",`
 touch-action: pan-x;
 `,[f("slides",`
 flex-direction: column;
 `),v("fade",[f("slide",`
 top: 50%;
 left: unset;
 transform: translateY(-50%);
 `)]),v("card",[f("slide",`
 top: 50%;
 left: unset;
 transform: translateY(-50%) translateZ(-400px);
 `,[v("current",`
 transform: translateY(-50%) translateZ(0);
 `),v("prev",`
 transform: translateY(-100%) translateZ(-200px);
 `),v("next",`
 transform: translateY(0%) translateZ(-200px);
 `)])])]),v("usercontrol",[f("slides",[V(">",[V("div",`
 position: absolute;
 top: 50%;
 left: 50%;
 width: 100%;
 height: 100%;
 transform: translate(-50%, -50%);
 `)])])]),v("left",[f("dots",`
 transform: translateY(-50%);
 top: 50%;
 left: 12px;
 flex-direction: column;
 `,[v("line",[f("dot",`
 width: 4px;
 height: var(--n-dot-line-width);
 margin: 4px 0;
 transition:
 height .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[v("active",`
 height: var(--n-dot-line-width-active);
 `)])])]),f("dot",`
 margin: 4px 0;
 `)]),f("arrow-group",`
 position: absolute;
 display: flex;
 flex-wrap: nowrap;
 `),v("vertical",[f("arrow",`
 transform: rotate(90deg);
 `)]),v("show-arrow",[v("bottom",[f("dots",`
 transform: translateX(0);
 bottom: 18px;
 left: 18px;
 `)]),v("top",[f("dots",`
 transform: translateX(0);
 top: 18px;
 left: 18px;
 `)]),v("left",[f("dots",`
 transform: translateX(0);
 top: 18px;
 left: 18px;
 `)]),v("right",[f("dots",`
 transform: translateX(0);
 top: 18px;
 right: 18px;
 `)])]),v("left",[f("arrow-group",`
 bottom: 12px;
 left: 12px;
 flex-direction: column;
 `,[V("> *:first-child",`
 margin-bottom: 12px;
 `)])]),v("right",[f("dots",`
 transform: translateY(-50%);
 top: 50%;
 right: 12px;
 flex-direction: column;
 `,[v("line",[f("dot",`
 width: 4px;
 height: var(--n-dot-line-width);
 margin: 4px 0;
 transition:
 height .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[v("active",`
 height: var(--n-dot-line-width-active);
 `)])])]),f("dot",`
 margin: 4px 0;
 `),f("arrow-group",`
 bottom: 12px;
 right: 12px;
 flex-direction: column;
 `,[V("> *:first-child",`
 margin-bottom: 12px;
 `)])]),v("top",[f("dots",`
 transform: translateX(-50%);
 top: 12px;
 left: 50%;
 `,[v("line",[f("dot",`
 margin: 0 4px;
 `)])]),f("dot",`
 margin: 0 4px;
 `),f("arrow-group",`
 top: 12px;
 right: 12px;
 `,[V("> *:first-child",`
 margin-right: 12px;
 `)])]),v("bottom",[f("dots",`
 transform: translateX(-50%);
 bottom: 12px;
 left: 50%;
 `,[v("line",[f("dot",`
 margin: 0 4px;
 `)])]),f("dot",`
 margin: 0 4px;
 `),f("arrow-group",`
 bottom: 12px;
 right: 12px;
 `,[V("> *:first-child",`
 margin-right: 12px;
 `)])]),v("fade",[f("slide",`
 position: absolute;
 opacity: 0;
 transition-property: opacity;
 pointer-events: none;
 `,[v("current",`
 opacity: 1;
 pointer-events: auto;
 `)])]),v("card",[f("slides",`
 perspective: 1000px;
 `),f("slide",`
 position: absolute;
 left: 50%;
 opacity: 0;
 transform: translateX(-50%) translateZ(-400px);
 transition-property: opacity, transform;
 `,[v("current",`
 opacity: 1;
 transform: translateX(-50%) translateZ(0);
 z-index: 1;
 `),v("prev",`
 opacity: 0.4;
 transform: translateX(-100%) translateZ(-200px);
 `),v("next",`
 opacity: 0.4;
 transform: translateX(0%) translateZ(-200px);
 `)])])]),Co=["transitionDuration","transitionTimingFunction"],Ro=Object.assign(Object.assign({},ot.props),{defaultIndex:{type:Number,default:0},currentIndex:Number,showArrow:Boolean,dotType:{type:String,default:"dot"},dotPlacement:{type:String,default:"bottom"},slidesPerView:{type:[Number,String],default:1},spaceBetween:{type:Number,default:0},centeredSlides:Boolean,direction:{type:String,default:"horizontal"},autoplay:Boolean,interval:{type:Number,default:5e3},loop:{type:Boolean,default:!0},effect:{type:String,default:"slide"},showDots:{type:Boolean,default:!0},trigger:{type:String,default:"click"},transitionStyle:{type:Object,default:()=>({transitionDuration:"300ms"})},transitionProps:Object,draggable:Boolean,prevSlideStyle:[Object,String],nextSlideStyle:[Object,String],touchable:{type:Boolean,default:!0},mousewheel:Boolean,keyboard:Boolean,"onUpdate:currentIndex":Function,onUpdateCurrentIndex:Function});let Ie=!1;const zo=te({name:"Carousel",props:Ro,setup(e){const{mergedClsPrefixRef:o,inlineThemeDisabled:s}=ge(e),l=L(null),r=L(null),h=L([]),R={value:[]},z=g(()=>e.direction==="vertical"),P=g(()=>z.value?"height":"width"),_=g(()=>z.value?"bottom":"right"),p=g(()=>e.effect==="slide"),y=g(()=>e.loop&&e.slidesPerView===1&&p.value),I=g(()=>e.effect==="custom"),U=g(()=>!p.value||e.centeredSlides?1:e.slidesPerView),B=g(()=>I.value?1:e.slidesPerView),k=g(()=>U.value==="auto"||e.slidesPerView==="auto"&&e.centeredSlides),D=L({width:0,height:0}),A=g(()=>{const{value:t}=h;if(!t.length)return[];const{value:n}=k;if(n)return t.map(w=>Qe(w));const{value:a}=B,{value:u}=D,{value:d}=P;let i=u[d];if(a!=="auto"){const{spaceBetween:w}=e,E=i-(a-1)*w,de=1/Math.max(1,a);i=E*de}const x=Object.assign(Object.assign({},u),{[d]:i});return t.map(()=>x)}),O=g(()=>{const{value:t}=A;if(!t.length)return[];const{centeredSlides:n,spaceBetween:a}=e,{value:u}=P,{[u]:d}=D.value;let i=0;return t.map(({[u]:x})=>{let w=i;return n&&(w+=(x-d)/2),i+=x+a,w})}),K=L(!1),xe=g(()=>{const{transitionStyle:t}=e;return t?Ze(t,Co):{}}),me=g(()=>I.value?0:po(xe.value.transitionDuration)),Ee=g(()=>{const{value:t}=h;if(!t.length)return[];const n=!(k.value||B.value===1),a=x=>{if(n){const{value:w}=P;return{[w]:`${A.value[x][w]}px`}}};if(I.value)return t.map((x,w)=>a(w));const{effect:u,spaceBetween:d}=e,{value:i}=_;return t.reduce((x,w,E)=>{const de=Object.assign(Object.assign({},a(E)),{[`margin-${i}`]:`${d}px`});return x.push(de),K.value&&(u==="fade"||u==="card")&&Object.assign(de,xe.value),x},[])}),N=g(()=>{const{value:t}=U,{length:n}=h.value;if(t!=="auto")return Math.max(n-t,0)+1;{const{value:a}=A,{length:u}=a;if(!u)return n;const{value:d}=O,{value:i}=P,x=D.value[i];let w=a[a.length-1][i],E=u;for(;E>1&&w<x;)E--,w+=d[E]-d[E-1];return pe(E+1,1,u)}}),ne=g(()=>vo(N.value,y.value)),mt=ke(e.defaultIndex,y.value),be=L(Ge(mt,N.value,y.value)),j=Ht(Kt(e,"currentIndex"),be),$=g(()=>ke(j.value,y.value));function q(t){var n,a;t=pe(t,0,N.value-1);const u=Ge(t,N.value,y.value),{value:d}=j;u!==j.value&&(be.value=u,(n=e["onUpdate:currentIndex"])===null||n===void 0||n.call(e,u,d),(a=e.onUpdateCurrentIndex)===null||a===void 0||a.call(e,u,d))}function oe(t=$.value){return co(t,N.value,e.loop)}function se(t=$.value){return fo(t,N.value,e.loop)}function bt(t){const n=Z(t);return n!==null&&oe()===n}function _t(t){const n=Z(t);return n!==null&&se()===n}function Ne(t){return $.value===Z(t)}function wt(t){return j.value===t}function $e(){return oe()===null}function Te(){return se()===null}function _e(t){const n=pe(ke(t,y.value),0,N.value);(t!==j.value||n!==$.value)&&q(n)}function we(){const t=oe();t!==null&&q(t)}function ae(){const t=se();t!==null&&q(t)}function yt(){(!T||!y.value)&&we()}function St(){(!T||!y.value)&&ae()}let T=!1,W=0;const ye=L({});function re(t,n=0){ye.value=Object.assign({},xe.value,{transform:z.value?`translateY(${-t}px)`:`translateX(${-t}px)`,transitionDuration:`${n}ms`})}function G(t=0){p.value?Se($.value,t):W!==0&&(!T&&t>0&&(T=!0),re(W=0,t))}function Se(t,n){const a=Ve(t);a!==W&&n>0&&(T=!0),W=Ve($.value),re(a,n)}function Ve(t){let n;return t>=N.value-1?n=je():n=O.value[t]||0,n}function je(){if(U.value==="auto"){const{value:t}=P,{[t]:n}=D.value,{value:a}=O,u=a[a.length-1];let d;if(u===void 0)d=n;else{const{value:i}=A;d=u+i[i.length-1][t]}return d-n}else{const{value:t}=O;return t[N.value-1]||0}}const J={currentIndexRef:j,to:_e,prev:yt,next:St,isVertical:()=>z.value,isHorizontal:()=>!z.value,isPrev:bt,isNext:_t,isActive:Ne,isPrevDisabled:$e,isNextDisabled:Te,getSlideIndex:Z,getSlideStyle:zt,addSlide:Ct,removeSlide:Rt,onCarouselItemClick:Pt};ho(J);function Ct(t){t&&h.value.push(t)}function Rt(t){if(!t)return;const n=Z(t);n!==-1&&h.value.splice(n,1)}function Z(t){return typeof t=="number"?t:t?h.value.indexOf(t):-1}function zt(t){const n=Z(t);if(n!==-1){const a=[Ee.value[n]],u=J.isPrev(n),d=J.isNext(n);return u&&a.push(e.prevSlideStyle||""),d&&a.push(e.nextSlideStyle||""),on(a)}}function Pt(t,n){let a=!T&&!ue&&!Pe;e.effect==="card"&&a&&!Ne(t)&&(_e(t),a=!1),a||(n.preventDefault(),n.stopPropagation())}let ie=null;function le(){ie&&(clearInterval(ie),ie=null)}function F(){le(),!e.autoplay||ne.value<2||(ie=window.setInterval(ae,e.interval))}let Ce=0,Re=0,M=0,ze=0,ue=!1,Pe=!1;function Oe(t){var n;if(Ie||!(!((n=r.value)===null||n===void 0)&&n.contains(sn(t))))return;Ie=!0,ue=!0,Pe=!1,ze=Date.now(),le(),t.type!=="touchstart"&&!t.target.isContentEditable&&t.preventDefault();const a=Je(t)?t.touches[0]:t;z.value?Re=a.clientY:Ce=a.clientX,e.touchable&&(ee("touchmove",document,ce),ee("touchend",document,X),ee("touchcancel",document,X)),e.draggable&&(ee("mousemove",document,ce),ee("mouseup",document,X))}function ce(t){const{value:n}=z,{value:a}=P,u=Je(t)?t.touches[0]:t,d=n?u.clientY-Re:u.clientX-Ce,i=D.value[a];M=pe(d,-i,i),t.cancelable&&t.preventDefault(),p.value&&re(W-M,0)}function X(){const{value:t}=$;let n=t;if(!T&&M!==0&&p.value){const a=W-M,u=[...O.value.slice(0,N.value-1),je()];let d=null;for(let i=0;i<u.length;i++){const x=Math.abs(u[i]-a);if(d!==null&&d<x)break;d=x,n=i}}if(n===t){const a=Date.now()-ze,{value:u}=P,d=D.value[u];M>d/2||M/a>.4?n=oe(t):(M<-d/2||M/a<-.4)&&(n=se(t))}n!==null&&n!==t?(Pe=!0,q(n),We(()=>{(!y.value||be.value!==j.value)&&G(me.value)})):G(me.value),Me(),F()}function Me(){ue&&(Ie=!1),ue=!1,Ce=0,Re=0,M=0,ze=0,Q("touchmove",document,ce),Q("touchend",document,X),Q("touchcancel",document,X),Q("mousemove",document,ce),Q("mouseup",document,X)}function kt(){if(p.value&&T){const{value:t}=$;Se(t,0)}else F();p.value&&(ye.value.transitionDuration="0ms"),T=!1}function It(t){if(t.preventDefault(),T)return;let{deltaX:n,deltaY:a}=t;t.shiftKey&&!n&&(n=a);const u=-1,d=1,i=(n||a)>0?d:u;let x=0,w=0;z.value?w=i:x=i;const E=10;(w*a>=E||x*n>=E)&&(i===d&&!Te()?ae():i===u&&!$e()&&we())}function Dt(){D.value=Qe(l.value,!0),F()}function At(){var t,n;k.value&&((n=(t=A.effect).scheduler)===null||n===void 0||n.call(t),A.effect.run())}function Et(){e.autoplay&&le()}function Nt(){e.autoplay&&F()}tt(()=>{qt(F),requestAnimationFrame(()=>K.value=!0)}),nt(()=>{Me(),le()}),Gt(()=>{const{value:t}=h,{value:n}=R,a=new Map,u=i=>a.has(i)?a.get(i):-1;let d=!1;for(let i=0;i<t.length;i++){const x=n.findIndex(w=>w.el===t[i]);x!==i&&(d=!0),a.set(t[i],x)}d&&t.sort((i,x)=>u(i)-u(x))}),fe($,(t,n)=>{if(t!==n)if(F(),p.value){if(y.value){const{value:a}=N;ne.value>2&&t===a-2&&n===1?t=0:t===1&&n===a-2&&(t=a-1)}Se(t,me.value)}else G()},{immediate:!0}),fe([y,U],()=>void We(()=>{q($.value)})),fe(O,()=>{p.value&&G()},{deep:!0}),fe(p,t=>{t?G():(T=!1,re(W=0))});const $t=g(()=>({onTouchstartPassive:e.touchable?Oe:void 0,onMousedown:e.draggable?Oe:void 0,onWheel:e.mousewheel?It:void 0})),Tt=g(()=>Object.assign(Object.assign({},Ze(J,["to","prev","next","isPrevDisabled","isNextDisabled"])),{total:ne.value,currentIndex:j.value})),Vt=g(()=>({total:ne.value,currentIndex:j.value,to:J.to})),jt={getCurrentIndex:()=>j.value,to:_e,prev:we,next:ae},Ot=ot("Carousel","-carousel",So,lo,e,o),Le=g(()=>{const{common:{cubicBezierEaseInOut:t},self:{dotSize:n,dotColor:a,dotColorActive:u,dotColorFocus:d,dotLineWidth:i,dotLineWidthActive:x,arrowColor:w}}=Ot.value;return{"--n-bezier":t,"--n-dot-color":a,"--n-dot-color-focus":d,"--n-dot-color-active":u,"--n-dot-size":n,"--n-dot-line-width":i,"--n-dot-line-width-active":x,"--n-arrow-color":w}}),Y=s?Jt("carousel",void 0,Le,e):void 0;return Object.assign(Object.assign({mergedClsPrefix:o,selfElRef:l,slidesElRef:r,slideVNodes:R,duplicatedable:y,userWantsControl:I,autoSlideSize:k,realIndex:$,slideStyles:Ee,translateStyle:ye,slidesControlListeners:$t,handleTransitionEnd:kt,handleResize:Dt,handleSlideResize:At,handleMouseenter:Et,handleMouseleave:Nt,isActive:wt,arrowSlotProps:Tt,dotSlotProps:Vt},jt),{cssVars:s?void 0:Le,themeClass:Y==null?void 0:Y.themeClass,onRender:Y==null?void 0:Y.onRender})},render(){var e;const{mergedClsPrefix:o,showArrow:s,userWantsControl:l,slideStyles:r,dotType:h,dotPlacement:R,slidesControlListeners:z,transitionProps:P={},arrowSlotProps:_,dotSlotProps:p,$slots:{default:y,dots:I,arrow:U}}=this,B=y&&Qt(y())||[];let k=Po(B);return k.length||(k=B.map(D=>S(yo,null,{default:()=>et(D)}))),this.duplicatedable&&(k=uo(k)),this.slideVNodes.value=k,this.autoSlideSize&&(k=k.map(D=>S(Ue,{onResize:this.handleSlideResize},{default:()=>D}))),(e=this.onRender)===null||e===void 0||e.call(this),S("div",Object.assign({ref:"selfElRef",class:[this.themeClass,`${o}-carousel`,this.direction==="vertical"&&`${o}-carousel--vertical`,this.showArrow&&`${o}-carousel--show-arrow`,`${o}-carousel--${R}`,`${o}-carousel--${this.direction}`,`${o}-carousel--${this.effect}`,l&&`${o}-carousel--usercontrol`],style:this.cssVars},z,{onMouseenter:this.handleMouseenter,onMouseleave:this.handleMouseleave}),S(Ue,{onResize:this.handleResize},{default:()=>S("div",{ref:"slidesElRef",class:`${o}-carousel__slides`,role:"listbox",style:this.translateStyle,onTransitionend:this.handleTransitionEnd},l?k.map((D,A)=>S("div",{style:r[A],key:A},en(S(nn,Object.assign({},P),{default:()=>D}),[[tn,this.isActive(A)]]))):k)}),this.showDots&&p.total>1&&Be(I,p,()=>[S(xo,{key:h+R,total:p.total,currentIndex:p.currentIndex,dotType:h,trigger:this.trigger,keyboard:this.keyboard})]),s&&Be(U,_,()=>[S(_o,null)]))}});function Po(e){return e.reduce((o,s)=>(wo(s)&&o.push(s),o),[])}const ko="/assets/1-BvpPxk1I.jpg",Io="/assets/2-C2O7qU-2.jpg",Do="/assets/3-D2R7-_Vs.jpg",Ao="/assets/4-C0zrly0K.jpg",Eo="/home/1.png",No="/home/2.jpg",$o="/home/3.jpg",To="/home/4.jpg",Vo="/home/5.jpg",jo="/home/6.jpg",Oo="/home/board/my.jpg",Mo="/home/board/ns.png",Lo="/home/board/om.png",Uo="/home/board/ya.png",C=e=>(un("data-v-419fb003"),e=e(),cn(),e),Bo=C(()=>c("img",{class:"carousel-img",src:ko},null,-1)),Wo=C(()=>c("img",{class:"carousel-img",src:Io},null,-1)),Zo=C(()=>c("img",{class:"carousel-img",src:Do},null,-1)),Fo=C(()=>c("img",{class:"carousel-img",src:Ao},null,-1)),Xo=C(()=>c("h2",{class:"mt-6"},"世界游泳锦标赛",-1)),Yo=C(()=>c("p",{class:"gray mt-6"}," 世界泳联锦标赛（英语：World Aquatics Championships，2022年前为国际泳联世界锦标赛，英语：FINA World Championships），又称世界游泳锦标赛，是由世界水上运动（前称国际游泳联合会）主办的最高级别国际性游泳赛事。1973年起开始举行，每2年举行一届，在1978年至1998年曾经每4年举行一届，在2001年开始恢复每2年举行一届。 ",-1)),Ho=C(()=>c("div",{class:"info-img-wrap"},[c("img",{class:"info-img",src:Eo,alt:""})],-1)),Ko=C(()=>c("div",{class:"info-img-wrap"},[c("img",{class:"info-img",src:No,alt:""})],-1)),qo={class:"bg-slate-100"},Go=C(()=>c("h2",{class:"mt-6"},"2024年世界游泳锦标赛",-1)),Jo=C(()=>c("p",{class:"gray mt-6"}," 2024年世界游泳锦标赛，为第21届世界游泳锦标赛，于2024年2月2日至18日在卡塔尔多哈举行[1]。是届赛事原定于2023年秋季举行，因福冈世界游泳锦标赛延期至2023年，本届赛事亦因而顺延至2024年。这是多哈首次举办世界游泳锦标赛，亦是阿拉伯世界第一次有城市举办世界游泳锦标赛。本届赛事距离巴黎奥运开幕只有5个月，这也是世界游泳锦标赛首次在奥运年举行 ",-1)),Qo=C(()=>c("div",{class:"h-64"},[c("img",{class:"info-img",src:$o,alt:""})],-1)),es=C(()=>c("div",{class:"h-64"},[c("img",{class:"info-img",src:To,alt:""})],-1)),ts=C(()=>c("div",{class:"h-64"},[c("img",{class:"info-img",src:Vo,alt:""})],-1)),ns={class:"h-full"},os=C(()=>c("h2",null,"2024年世界游泳锦标赛跳水比赛",-1)),ss=C(()=>c("p",{class:"gray"}," 2024年世界游泳锦标赛跳水比赛是2024年世界游泳锦标赛的其中一个比赛项目，于2024年2月2日至10日在卡塔尔多哈的哈马德水上运动中心举行。跳水比赛共产生13枚金牌[1][2]。此次比赛同时也是2024年巴黎奥运跳水项目的资格赛之一，个人小项提供余下未分配的运动员名额，直至入围奥运正赛总人数达到相应数量为止，每个双人小项则提供4个席位[3]。 ",-1)),as=C(()=>c("div",{class:"h-80"},[c("img",{class:"info-img",src:jo,alt:""})],-1)),rs={class:"bg-neutral-400"},is=C(()=>c("h2",{class:"text-white text-center"},"合作伙伴",-1)),ls=C(()=>c("a",{href:"https://www.myrthapools.com/zh/",target:"_blank"},[c("div",{class:"bg-white h-44"},[c("img",{class:"info-img",src:Oo,alt:""})])],-1)),us=C(()=>c("a",{href:"https://en.nongfuspring.com/",target:"_blank"},[c("div",{class:"bg-white h-44"},[c("img",{class:"info-img",src:Mo,alt:""})])],-1)),cs=C(()=>c("a",{href:"https://www.omegawatches.com.hk/zh-hk/",target:"_blank"},[c("div",{class:"bg-white h-44"},[c("img",{class:"info-img",src:Lo,alt:""})])],-1)),ds=C(()=>c("a",{href:"https://www.yakult.co.jp/english/",target:"_blank"},[c("div",{class:"bg-white h-44"},[c("img",{class:"info-img",src:Uo,alt:""})])],-1)),fs=te({__name:"HomeView",setup(e){return(o,s)=>{const l=zo,r=fn,h=vn,R=pn;return ln(),an(rn,null,[m(l,{draggable:"",autoplay:"",interval:3e3},{default:b(()=>[Bo,Wo,Zo,Fo]),_:1}),m(ve,{class:"py-6"},{default:b(()=>[m(R,{align:"center",vertical:""},{default:b(()=>[Xo,Yo,m(h,{"x-gap":"20",cols:"1 800:2","y-gap":"20",class:"mt-6"},{default:b(()=>[m(r,null,{default:b(()=>[Ho]),_:1}),m(r,null,{default:b(()=>[Ko]),_:1})]),_:1})]),_:1})]),_:1}),c("div",qo,[m(ve,{class:"py-6"},{default:b(()=>[Go,Jo,m(h,{"x-gap":"20",cols:"1 800:3","y-gap":"20",class:"mt-6"},{default:b(()=>[m(r,null,{default:b(()=>[Qo]),_:1}),m(r,null,{default:b(()=>[es]),_:1}),m(r,null,{default:b(()=>[ts]),_:1})]),_:1})]),_:1})]),m(ve,{class:"py-6"},{default:b(()=>[m(h,{"x-gap":"20",cols:"1 800:2","y-gap":"20",class:"mt-6"},{default:b(()=>[m(r,null,{default:b(()=>[c("div",ns,[m(R,{vertical:"",class:"h-full"},{default:b(()=>[os,m(R,{align:"center",class:"flex-1"},{default:b(()=>[ss]),_:1})]),_:1})])]),_:1}),m(r,null,{default:b(()=>[as]),_:1})]),_:1})]),_:1}),c("div",rs,[m(ve,{class:"py-6"},{default:b(()=>[is,m(h,{"x-gap":"12","y-gap":"20",cols:"2 800:4",class:"mt-6"},{default:b(()=>[m(r,null,{default:b(()=>[ls]),_:1}),m(r,null,{default:b(()=>[us]),_:1}),m(r,null,{default:b(()=>[cs]),_:1}),m(r,null,{default:b(()=>[ds]),_:1})]),_:1})]),_:1})])],64)}}}),xs=dn(fs,[["__scopeId","data-v-419fb003"]]);export{xs as default};
